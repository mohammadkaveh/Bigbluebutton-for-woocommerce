<?php

class Bigbluebutton_Admin_Helper {

	public static function generate_random_code( $length = 10 ) {
		$default_code = bin2hex( random_bytes( $length / 2 ) );
		return $default_code;
	}
}
