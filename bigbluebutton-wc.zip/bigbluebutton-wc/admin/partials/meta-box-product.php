<?php 
	
	$chk_bbb_room = get_post_meta( get_the_ID(),'chk_bbb_room',true);
	if($chk_bbb_room =='true') {
		$chk_bbb_room = 'checked';
		}else{
		$chk_bbb_room = '';
	}
	
	
	
	
	$chk_bbb_room_record = get_post_meta( get_the_ID(),'chk_bbb_room_record',true);
	if($chk_bbb_room_record =='true') {
		$chk_bbb_room_record = 'checked';
		}else{
		$chk_bbb_room_record = '';
	}
	
	
	$chk_date_bbb_room = get_post_meta( get_the_ID(),'chk_date_bbb_room',true);
	if($chk_date_bbb_room =='true') {
		$chk_date_bbb_room = 'checked';
		}else{
		$chk_date_bbb_room = '';
	}
	
	
	
	
	
	$setday =  get_post_meta(  get_the_ID(),'bbb_room_start_date',true); 
	$settime =  get_post_meta(  get_the_ID() ,'bbb_room_start_time',true); 
	$settimeend =  get_post_meta(  get_the_ID() ,'bbb_room_end_time',true); 
	$setdayend =  get_post_meta( get_the_ID() ,'bbb_room_end_date',true); 
	
	
	if(! $setday){
		$setday = date( 'Y-m-d', current_time( 'timestamp', 0 ) );
	}
	
	
	if(! $setdayend){
		$setdayend = date( 'Y-m-d', current_time( 'timestamp', 0 ) );
	}
	
	
	if(! $settime)	{
		$settime = date( 'H:i', current_time( 'timestamp', 0 ) );
		$settimeend = date( 'H:i', current_time( 'timestamp', 0 ));
		$settimeend  = date( 'H:i',strtotime($settimeend.'+1 hour'));
		
	}
	
	
	
	
	
	
	
	global $post;
	
	$args = array(
	'post_type' => 'bbb-room',
	'post_status' => 'publish',
	'posts_per_page' => -1,
	);
	$data=get_posts($args);
	


	$select_option =  get_post_meta( get_the_ID() ,'name_bbb_room',true); 
	
	
?>


<table class="form-table lms_table" role="presentation">
	
	<tbody>
		<tr>
			<th scope="row"><label for="chk_bbb_room"> <?php esc_html_e( 'room', 'bigbluebutton' ); ?></label></th>
			<td class="td_enable"><label for="survey_select"><?php esc_html_e( 'enable', 'bigbluebutton' ); ?> </label>
				<input type="checkbox" id="chk_bbb_room" name="chk_bbb_room" value="true" <?php echo $chk_bbb_room; ?>>
			</td>
		</tr>
		
		
		<tr>
			<th scope="row"><label for="name_bbb_room"><?php esc_html_e( 'room name', 'bigbluebutton' ); ?></label></th>
			<td>
				<select  disabled name="name_bbb_room" id="name_bbb_room" >
					<?php    if($data){ foreach($data as $key => $value){
					if ($value->ID == $select_option){$selected = 'selected';} else{$selected = '';}?>	
					<option value="<?php echo(  $value->ID); ?>" <?php echo $selected;  ?> > <?php echo  $value->post_title; ?> </option>
					<?php } }?>
					
				</select>
			</td>
		</tr>	
		
		
		

		<tr>
			<th scope="row"><label for="chk_date_bbb_room"><?php esc_html_e( 'scheduling', 'bigbluebutton' ); ?> </label></th>
			<td class="td_enable"><label for="survey_select"><?php esc_html_e( 'enable', 'bigbluebutton' ); ?> </label>
				<input disabled type="checkbox" id="chk_date_bbb_room" name="chk_date_bbb_room" value="true" <?php echo $chk_date_bbb_room; ?>>
			</td>
		</tr>


		<tr>
			<th scope="row"><label for="bbb_room_start_date"><?php esc_html_e( 'start date', 'bigbluebutton' ); ?> </label>
			</th>
			<td>
				<input disabled type="date" name="bbb_room_start_date" id="bbb_room_start_date" value="<?php echo $setday ?>" >
				<input disabled type="time" name="bbb_room_start_time" id="bbb_room_start_time" value="<?php echo $settime ?>" >
			</td>
		</tr>
		
		
		
		
		
		<tr>
			<th scope="row"><label for="bbb_room_end_date"><?php esc_html_e( 'end date', 'bigbluebutton' ); ?></label>
			</th>
			<td>
				<input disabled type="date" name="bbb_room_end_date" id="bbb_room_end_date" value="<?php echo $setdayend ?>" >
				<input disabled type="time" name="bbb_room_end_time" id="bbb_room_end_time" value="<?php echo $settimeend ?>" >
			</td>
		</tr>
		
		
		
		
		<tr>
			<th scope="row"><label for="survey_select"> <?php esc_html_e( 'show record', 'bigbluebutton' ); ?> </label></th>
			
			<td class="td_enable" ><label for="survey_select"> <?php esc_html_e( 'enable', 'bigbluebutton' ); ?></label>
				<input disabled type="checkbox" id="chk_bbb_room_record" name="chk_bbb_room_record" value="true" <?php echo $chk_bbb_room_record; ?> >
			</td>
		</tr>
		
		
	</tbody>
</table>








