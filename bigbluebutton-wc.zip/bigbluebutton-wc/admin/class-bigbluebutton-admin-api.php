<?php

class Bigbluebutton_Admin_Api {

	public function save_room( $post_id ) {

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}
	///=========================================save product =====================================
	if (get_post_type( $post_id ) == 'product'){
	
		$chk_bbb_room     = ( array_key_exists( 'chk_bbb_room', $_POST ) && sanitize_text_field( $_POST['chk_bbb_room'] ) == 'true' );
		$chk_bbb_room_record     = ( array_key_exists( 'chk_bbb_room_record', $_POST ) && sanitize_text_field( $_POST['chk_bbb_room_record'] ) == 'true' );
		$chk_date_bbb_room     = ( array_key_exists( 'chk_date_bbb_room', $_POST ) && sanitize_text_field( $_POST['chk_date_bbb_room'] ) == 'true' );
		$bbb_room_start_date = sanitize_text_field( $_POST['bbb_room_start_date'] ) ;
		$bbb_room_start_time = sanitize_text_field( $_POST['bbb_room_start_time'] );
		$bbb_room_end_date = sanitize_text_field( $_POST['bbb_room_end_date'] );
		$bbb_room_end_time = sanitize_text_field( $_POST['bbb_room_end_time'] );
		$name_bbb_room = sanitize_text_field( $_POST['name_bbb_room'] );


		update_post_meta( $post_id,'chk_bbb_room',( $chk_bbb_room ? 'true' : 'false' ));
		update_post_meta( $post_id,'chk_date_bbb_room',	( $chk_date_bbb_room ? 'true' : 'false' ));
		update_post_meta( $post_id,'chk_bbb_room_record',( $chk_bbb_room_record ? 'true' : 'false' ));

		update_post_meta( $post_id,'bbb_room_start_date',$bbb_room_start_date); 
		update_post_meta( $post_id ,'bbb_room_start_time',$bbb_room_start_time ); 
		update_post_meta( $post_id,'bbb_room_end_time',	$bbb_room_end_time); 
		update_post_meta( $post_id ,'bbb_room_end_date',$bbb_room_end_date); 

		update_post_meta( $post_id ,'name_bbb_room',$name_bbb_room); 



	}



		///======================================= save bbb ================================================
		if ( $this->can_save_room() ) {
		
		
			$moderator_code = sanitize_text_field( $_POST['bbb-moderator-code'] );
			$viewer_code    = sanitize_text_field( $_POST['bbb-viewer-code'] );
			$recordable     = ( array_key_exists( 'bbb-room-recordable', $_POST ) && sanitize_text_field( $_POST['bbb-room-recordable'] ) == 'checked' );

			$wait_for_mod = ( isset( $_POST['bbb-room-wait-for-moderator'] ) && sanitize_text_field( $_POST['bbb-room-wait-for-moderator'] ) == 'checked' );

			// Ensure neither code is empty.
			if ( '' == $moderator_code ) {
				$moderator_code = Bigbluebutton_Admin_Helper::generate_random_code();
			}
			if ( '' == $viewer_code ) {
				$viewer_code = Bigbluebutton_Admin_Helper::generate_random_code();
			}

			// Ensure the moderator code is not the same as the viewer code.
			if ( $moderator_code === $viewer_code ) {
				$viewer_code = $moderator_code . Bigbluebutton_Admin_Helper::generate_random_code( 1 );
			}

			// Add room codes to postmeta data.
			update_post_meta( $post_id, 'bbb-room-moderator-code', $moderator_code );
			update_post_meta( $post_id, 'bbb-room-viewer-code', $viewer_code );

			if ( ! get_post_meta( $post_id, 'bbb-room-meeting-id', true ) ) {
				update_post_meta( $post_id, 'bbb-room-meeting-id', sha1( home_url() . Bigbluebutton_Admin_Helper::generate_random_code( 12 ) ) );
			}

			// Update room recordable value.
			update_post_meta( $post_id, 'bbb-room-recordable', ( $recordable ? 'true' : 'false' ) );
			update_post_meta( $post_id, 'bbb-room-wait-for-moderator', ( $wait_for_mod ? 'true' : 'false' ) );

		} else {
			return $post_id;
		}
	}


	public function dismiss_admin_notices() {
		if ( isset( $_POST['type'] ) && 'bbb-' === substr( $_POST['type'], 0, 4 ) ) {
			$type = sanitize_text_field( $_POST['type'] );
			if ( wp_verify_nonce( $_POST['nonce'], $type ) ) {
				update_option( 'dismissed-' . $type, true );
			}
		}
	}


	private function can_save_room() {
		return ( isset( $_POST['bbb-moderator-code'] ) &&
			isset( $_POST['bbb-viewer-code'] ) &&
			isset( $_POST['bbb-room-moderator-code-nonce'] ) &&
			wp_verify_nonce( $_POST['bbb-room-moderator-code-nonce'], 'bbb-room-moderator-code-nonce' ) &&
			isset( $_POST['bbb-room-viewer-code-nonce'] ) &&
			wp_verify_nonce( $_POST['bbb-room-viewer-code-nonce'], 'bbb-room-viewer-code-nonce' ) &&
			isset( $_POST['bbb-room-wait-for-moderator-nonce'] ) &&
			wp_verify_nonce( $_POST['bbb-room-wait-for-moderator-nonce'], 'bbb-room-wait-for-moderator-nonce' ) &&
			( ! current_user_can( 'create_recordable_bbb_room' ) ||
				( isset( $_POST['bbb-room-recordable-nonce'] ) &&
				wp_verify_nonce( $_POST['bbb-room-recordable-nonce'], 'bbb-room-recordable-nonce' ) ) )
			);
	}
}
