<?php
class Bigbluebutton_Display_Helper {

	private $file;

	public function __construct( $file ) {
		$this->file = $file;
	}
	public function get_join_form_as_string( $room_id, $meta_nonce, $access_as_moderator, $access_as_viewer, $access_using_code ) {
		global $wp;
		$current_url         = home_url( add_query_arg( array(), $wp->request ) );
		$heartbeat_available = wp_script_is( 'heartbeat', 'registered' );
		ob_start();
		include $this->file . 'partials/bigbluebutton-join-display.php';
		$form = ob_get_contents();
		ob_end_clean();
		return $form;
	}

	public function get_collapsable_recordings_view_as_string( $room_id, $recordings, $manage_bbb_recordings, $view_extended_recording_formats ) {
		$html_recordings = $this->get_recordings_as_string( $room_id, $recordings, $manage_bbb_recordings, $view_extended_recording_formats );
		ob_start();
		include $this->file . 'partials/bigbluebutton-collapsable-recordings-display.php';
		$optional_recordings = ob_get_contents();
		ob_end_clean();
		return $optional_recordings;
	}

	private function get_recordings_as_string( $room_id, $recordings, $manage_bbb_recordings, $view_extended_recording_formats ) {
		$columns = 5;
		if ( $manage_bbb_recordings ) {
			$columns++;
		}
		$sort_fields = $this->set_order_by_field();
		ob_start();
		$meta_nonce                   = wp_create_nonce( 'bbb_manage_recordings_nonce' );
		$date_format                  = ( get_option( 'date_format' ) ? get_option( 'date_format' ) : 'Y-m-d' );
		$default_bbb_recording_format = 'presentation';
		include $this->file . 'partials/bigbluebutton-recordings-display.php';
		$html_recordings = ob_get_contents();
		ob_end_clean();
		return $html_recordings;
	}

	private function set_order_by_field() {
		$sort_asc_classes   = 'dashicons dashicons-arrow-up-alt2 bbb-header-icon';
		$sort_desc_classes  = 'dashicons dashicons-arrow-down-alt2 bbb-header-icon';
		$sort_meta_nounce   = wp_create_nonce( 'bbb_sort_recording_columns_nonce' );
		$custom_sort_fields = array(
			'name'        => null,
			'description' => null,
			'date'        => null,
		);

		if ( isset( $_GET['order'] ) && isset( $_GET['orderby'] ) && isset( $_GET['nonce'] ) && wp_verify_nonce( $_GET['nonce'], 'bbb_sort_recording_columns_nonce' ) ) {
			$new_direction    = ( sanitize_text_field( $_GET['order'] ) == 'asc' ? 'desc' : 'asc' );
			$new_sort_classes = ( 'asc' == $new_direction ? $sort_desc_classes : $sort_asc_classes ) . ' bbb-current-sort-icon';
			$selected_field   = sanitize_text_field( $_GET['orderby'] );

			if ( array_key_exists( $selected_field, $custom_sort_fields ) ) {
				$custom_sort_fields[ $selected_field ] = (object) array(
					'url'            => '?orderby=' . $selected_field . '&order=' . $new_direction . '&nonce=' . $sort_meta_nounce,
					'classes'        => $new_sort_classes,
					'header_classes' => 'bbb-column-header-highlight',
				);
			}
		}

		foreach ( $custom_sort_fields as $field => $values ) {
			if ( null === $custom_sort_fields[ $field ] ) {
				$custom_sort_fields[ $field ] = (object) array(
					'url'            => '?orderby=' . $field . '&order=asc&nonce=' . $sort_meta_nounce,
					'classes'        => $sort_asc_classes . ' bbb-hidden',
					'header_classes' => 'bbb-recordings-unselected-sortable-column',
				);
			}
		}

		return $custom_sort_fields;
	}

	public function get_room_list_dropdown_as_string( $rooms, $selected_room, $html_form ) {
		ob_start();
		include $this->file . 'partials/bigbluebutton-room-dropdown-display.php';
		$dropdown = ob_get_contents();
		ob_end_clean();
		return $dropdown;
	}
}
