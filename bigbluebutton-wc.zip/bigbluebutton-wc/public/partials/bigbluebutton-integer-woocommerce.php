<?php 
	
		
	//$setday =  get_post_meta(  get_the_ID(),'bbb_room_start_date',true); 
	///$settime =  get_post_meta(  get_the_ID() ,'bbb_room_start_time',true); 
	//$settimeend =  get_post_meta(  get_the_ID() ,'bbb_room_end_time',true); 
	//$setdayend =  get_post_meta( get_the_ID() ,'bbb_room_end_date',true); 
   
   // $chk_bbb_room_record = get_post_meta( get_the_ID(),'chk_bbb_room_record',true);
   




    $chk_bbb_room = get_post_meta( get_the_ID(),'chk_bbb_room',true);
    $bbb_room =  get_post_meta( get_the_ID() ,'name_bbb_room',true); 
	
	$bbb_date = get_post_meta( get_the_ID(),'bbb_room_start_date',true);
	$bbb_date_end = get_post_meta( get_the_ID(),'bbb_room_end_date',true);
	$bbb_time = get_post_meta( get_the_ID(),'bbb_room_start_time',true);
	$bbb_timeend = get_post_meta( get_the_ID(),'bbb_room_end_time',true);
	
	
	$chk_bbb_room_record   = get_post_meta( get_the_ID(),'chk_bbb_room_record',true);

    $chk_date_bbb_room = get_post_meta( get_the_ID(),'chk_date_bbb_room',true);
	$date_start  = date('Y-m-d H:i:s',strtotime($bbb_date . ' ' . $bbb_time));
	$date_end  =  date('Y-m-d H:i:s',strtotime($bbb_date_end . ' ' . $bbb_timeend));
	$date_now  =  date('Y-m-d H:i:s');
	
	
	$diff = strtotime($date_now) -  strtotime($date_end);
    $expire = false;
	if ( $diff > 0){
		$expire = true;
	}
	


    $diff = strtotime($date_start ) - strtotime($date_now) ;
    $before = false;
	if ( $diff > 0){
		$before = true;
	}

  //  echo jdate('H:i Y/n/j',date('Y-m-d H:i:s')) . '<br>';
 ////   echo 'before:' . $before . '<br>';
 //   echo 'expire:' . $expire;
	
?>

<?php if ($chk_bbb_room=='true'): ?>


	<div class="entry-content">
		


		<?php 
			if($chk_date_bbb_room =='true'){
				if (function_exists(jdate)){
					$d_start= jdate('H:i Y/n/j',$date_start);
					$d_end = jdate('H:i Y/n/j',$date_end);
				}else{
					$d_start = $date_start;
					$d_end = $date_end;
				}
				echo '<hr/>';
				echo esc_html_e( "room start time", "bigbluebutton" ) . ' :  ' .  $d_start . '<br>';
				echo  esc_html_e( "room ending time", "bigbluebutton" ) . ' :  ' . $d_end . '<br>';
				echo '<hr/>';
			}
		?>
		
		
	
        <?php if($before && $chk_date_bbb_room):  ?>
		<a   href="#"  style="text-align:center; width: 100%; display: block;" class="yellowbtn" ><?php esc_html_e( "room not start", "bigbluebutton" ); ?></a>
		<?php endif; ?>
		<?php if((!$expire && !$before && $chk_date_bbb_room) ||  ! $chk_date_bbb_room) echo do_shortcode('[bigbluebutton token="z'. $bbb_room .'"]'); ?>
		<?php if($expire && $chk_date_bbb_room):  ?>
		<a   href="#"  style="text-align:center; width: 100%; display: block;" class="yellowbtn" ><?php esc_html_e( "room ending", "bigbluebutton" ); ?> </a>
		<?php endif; ?>
		
		
		
			
		<?php if($chk_bbb_room_record =='true'): ?> 
		<?php echo do_shortcode('[bigbluebutton type="recording"  token="z'. $bbb_room .'"]'); ?>
		<?php endif; ?>
		
		


	</div>
	

<?php endif; ?>