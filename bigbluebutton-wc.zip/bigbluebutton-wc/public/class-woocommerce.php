<?php

class BBB_WC {

	public function __construct() {
        add_filter( 'woocommerce_is_purchasable', array($this,'hide_add_cart_if_already_purchased'), 9999, 2 );
        add_action( 'woocommerce_single_product_summary', array($this, 'woocommerce_add_wbinar'),999);
        
	}



///=====================================woocommerce add to card front=============================

 
public function hide_add_cart_if_already_purchased( $is_purchasable, $product ) {
    $chk_bbb_room = get_post_meta( $product->get_id() ,'chk_bbb_room',true);
    if ( wc_customer_bought_product( '', get_current_user_id(), $product->get_id() ) && $chk_bbb_room =='true' ) {
       $is_purchasable = false;
    }
    return $is_purchasable;
 }




///=====================================woocommerce webinar front=============================

 public function woocommerce_add_wbinar(){

    require 'partials/bigbluebutton-integer-woocommerce.php';
}





}
new BBB_WC;