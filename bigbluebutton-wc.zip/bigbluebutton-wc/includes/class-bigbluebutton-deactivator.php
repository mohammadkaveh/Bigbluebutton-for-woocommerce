<?php
class Bigbluebutton_Deactivator {

	/**
	 * Placeholder for deactivating plugin.
	 */
	public static function deactivate() {

	}

}
