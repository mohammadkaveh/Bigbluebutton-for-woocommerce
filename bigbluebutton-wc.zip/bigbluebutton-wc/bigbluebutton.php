<?php


/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link               https://arian.agency - https://blindsidenetworks.com
 * @since              1.0.0
 * @package            BigBlueButton for Woocommerce
 *
 * @wordpress-plugin
 * Plugin Name:       BigBlueButton for Woocommerce
 * Plugin URI:        https://arian.agency
 * Description:       This plugin allows you to manage your webinar room. <br>It also allows you to intergered bigbluebutton with WooCommerce plugin.
 * Version:           1.0.0
 * Author:            arian digitalagency - Blindside Networks
 * Author URI:        https://arian.agency
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       bigbluebutton
 * Domain Path:       /languages
 */


// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
define( 'BIGBLUEBUTTON_VERSION', '1.0.0' );



require  plugin_dir_path( __FILE__ ) . 'public/class-woocommerce.php'; 
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-bigbluebutton-activator.php
 */
function activate_bigbluebutton() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-bigbluebutton-activator.php';
	Bigbluebutton_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-bigbluebutton-deactivator.php
 */
function deactivate_bigbluebutton() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-bigbluebutton-deactivator.php';
	Bigbluebutton_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_bigbluebutton' );
register_deactivation_hook( __FILE__, 'deactivate_bigbluebutton' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-bigbluebutton.php';

function run_bigbluebutton() {

	$plugin = new Bigbluebutton();
	$plugin->run();

}
run_bigbluebutton();
